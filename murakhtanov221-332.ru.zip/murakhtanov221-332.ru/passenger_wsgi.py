# -*- coding: utf-8 -*-
import os, sys

sys.path.insert(0, '/var/www/u2910079/data/www/murakhtanov221-332.ru/academic_performance')
sys.path.insert(1, '/var/www/u2910079/data/venv/lib/python3.10/site-packages')

os.environ['DJANGO_SETTINGS_MODULE'] = 'academic_performance.settings'
from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()
